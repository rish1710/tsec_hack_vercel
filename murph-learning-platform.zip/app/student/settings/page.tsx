import { SettingsPage } from "@/components/settings-page"

export default function StudentSettingsPage() {
  return <SettingsPage role="student" />
}
